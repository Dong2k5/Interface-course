<template>
  <div class="adopt-form">
    <h3>Adoption Form</h3>
    <form @submit.prevent="submit" novalidate>
      <label for="u_name">Your name:</label>
      <input
        id="u_name"
        name="name"
        v-model="formData.name"
        required
        maxlength="20"
        pattern="[A-Za-z ]+"
      />
      <div class="error" v-if="errors.name">{{ errors.name }}</div>

      <label for="p_name">Pet name:</label>
      <input
        id="p_name"
        name="petName"
        v-model="formData.petName"
        required
        maxlength="20"
        pattern="[A-Za-z ]+"
      />
      <div class="error" v-if="errors.petName">{{ errors.petName }}</div>

      <label for="email">Email:</label>
      <input
        id="email"
        name="email"
        v-model="formData.email"
        type="email"
        required
      />
      <div class="error" v-if="errors.email">{{ errors.email }}</div>

      <label for="phone">Phone:</label>
      <input
        id="phone"
        name="phone"
        v-model="formData.phone"
        type="tel"
        required
        pattern="^\+09\d+$"
      />
      <div class="error" v-if="errors.phone">{{ errors.phone }}</div>

      <label for="address">Address:</label>
      <input id="address" name="address" v-model="formData.address" />

      <button type="submit">Submit</button>
    </form>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useAdoptions } from '../composables/useAdoptions.js'

export default {
  props: ['petId'],
  emits: ['submitted'],
  setup(props, { emit }) {
    const formData = ref({
      name: '',
      petName: '',
      email: '',
      phone: '',
      address: ''
    })
    const errors = ref({
      name: '',
      petName: '',
      email: '',
      phone: '',
      address: ''
    })

    const { addAdoption } = useAdoptions()

    const validate = () => {
      // reset errors
      errors.value = { name: '', petName: '', email: '', phone: '', address: '' }

      const nameRegex = /^[A-Za-z\s]{1,20}$/
      if (!nameRegex.test(formData.value.name)) {
        errors.value.name = 'Name is required, only letters/spaces allowed, max 20 chars.'
      }

      if (!nameRegex.test(formData.value.petName)) {
        errors.value.petName = 'Pet name is required, only letters/spaces allowed, max 20 chars.'
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(formData.value.email)) {
        errors.value.email = 'Please enter a valid email address.'
      }

      const phoneRegex = /^\+09\d+$/
      if (!phoneRegex.test(formData.value.phone)) {
        errors.value.phone = "Phone is required and must start with '+09' followed by digits."
      }

      // return true if no errors
      return Object.values(errors.value).every((e) => !e)
    }

    const submit = () => {
      if (!validate()) return
      addAdoption({ petId: props.petId, ...formData.value })
      alert('Your adoption request is pending admin approval!')
      formData.value = { name: '', petName: '', email: '', phone: '', address: '' }
      emit('submitted')
    }

    return { formData, errors, submit }
  }
}
</script>

<style scoped>
.error {
  color: red;
  font-size: 0.9em;
  margin-bottom: 0.5em;
}
</style>